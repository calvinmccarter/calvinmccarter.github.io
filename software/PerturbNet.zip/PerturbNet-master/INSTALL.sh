(cd Fast-sCGGM && make)
(cd EM-sCGGM && make)
(cd Mega-sCGGM && make)
